# Notas de lanzamiento

## Versión inicial

- [May 2018] https://github.com/swcarpentry/r-novice-gapminder-es

## Archivo de prelanzamiento

- [March 2018](https://github.com/Carpentries-ES/r-novice-gapminder)

## Lanzamientos de lecciones de inglés anteriores

R for Reproducible Scientific Analysis
- [Corriente](https://github.com/swcarpentry/r-novice-gapminder)
- [August 2017](https://zenodo.org/record/838770)
- [February 2017](https://zenodo.org/record/278224)
- [June 2016](https://zenodo.org/record/57520)
