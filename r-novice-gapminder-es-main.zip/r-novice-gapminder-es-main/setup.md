---
title: Configuración
---

Esta lección supone que tienes el software R,RStudio instalado en tu computadora.

R se puede descargar [aquí](https://cran.r-project.org/mirrors.html).

RStudio es un entorno de desarrollo integrado para R.
Se puede descargar [aquí](https://www.rstudio.com/products/rstudio/download/).
Necesitaras la versión de escritorio para tu computadora.
