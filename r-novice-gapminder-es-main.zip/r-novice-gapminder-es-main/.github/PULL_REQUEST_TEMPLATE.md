---

Por favor borra este texto antes de enviar tu pull request.

Agradecemos tu tiempo y esfuerzo para mejorar esta lección. ¡Gracias por contribuir!

Si esta contribución es parte de tu capacitación como **instructor**, envía un correo electrónico a [checkout@carpentries.org](mailto:checkout@carpentries.org) con un enlace a ésta contribución para que podamos registrar su progreso.

Por favor ten en cuenta que los **Maintainers** son voluntarios y pueden tardar más de 72 horas en responder. Si tienes alguna pregunta sobre el proceso de mantenimiento de la lección o te gustaría ofrecer su tiempo como **Maintainer**, comunícate con [Rayna Harris](mailto:rayna.harris@gmail.com).
